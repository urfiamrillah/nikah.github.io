		<div id="kLink" class="content-link-wrapper">

			<div class="content-link">

				<div class="content-links">

					<ul>
						<li><a href="index.php?page_id=2">TENTANG KAMI</a></li>
						<li><a href="index.php?page_id=122">TENTANG KRETEK</a></li>
						<li><a href="index.php?post_type=gallery_photo">GALERI</a></li>
						<li><a href="index.php?post_type=merchandise">MERCHANDISE</a></li>
					</ul>

				</div>

				<div class="content-link-foot">

					<div class="link-foot-secretariat pull-left">
						<?php if (mytheme_option('footer_address') && mytheme_option('footer_phone') && mytheme_option('footer_email')):?>
							<?php $address = mytheme_option('footer_address')?>
							<?php $phone = mytheme_option('footer_phone')?>
							<?php $email = mytheme_option('footer_email')?>
						<?php else:?>
							<?php $address = "Jalan Anggajaya 1 Gang Rajawali No.180 Condongcatur Sleman Yogyakarta";?>
							<?php $phone = "0274 4463054";?>
							<?php $email = "media.komtek@gmail.com";?>
						<?php endif;?>


						<p>Sekretariat:</p>

						<p><?php echo $address ?></p>

						<p>Telepon/Fax :<?php echo $phone ?> - Email : <a href="mailto:<?php echo $email ?>"<?php echo $email ?></a></p>

					</div>

					<div class="link-foot-social pull-right">
						<?php if (mytheme_option('facebook_link') && mytheme_option('twitter_link') && mytheme_option('youtube_link') && mytheme_option('blog_link')):?>
							<?php $facebook = mytheme_option('facebook_link')?>
							<?php $twitter = mytheme_option('twitter_link')?>
							<?php $youtube = mytheme_option('youtube_link')?>
							<?php $blog = mytheme_option('blog_link')?>
						<?php else:?>
							<?php $facebook = "http://www.facebook.com/pages/Komunitas-Kretek/279628405420047";?>
							<?php $twitter = "https://twitter.com/KomunitasKretek";?>
							<?php $youtube = "http://www.youtube.com/user/KomunitasKretek";?>
							<?php $blog = "http://matkretek.blogspot.com";?>
						<?php endif;?>

						<a href="<?php echo $facebook ?>"><img src="<?php bloginfo('template_directory'); ?>/img/fb.png" /></a>

						<a href="<?php echo $twitter ?>"><img src="<?php bloginfo('template_directory'); ?>/img/twitter.png" /></a>

						<a href="<?php echo $youtube ?>"><img src="<?php bloginfo('template_directory'); ?>/img/youtube.png" /></a>

						<a href="<?php echo $blog ?>"><img src="<?php bloginfo('template_directory'); ?>/img/chirp.png" /></a>

					</div>

				</div>

			</div>

		</div>

		<!-- end of link -->

		<div id="kFooter" class="content-footer-wrapper">

			<div class="content-footer">

				<div class="content-footer-left pull-left">

					<p>Copyright &copy; 2010 <a href="index.php">Komunitas Kretek</a></p>

					<p>All Rights Reserved</p>

				</div>

				<div class="content-footer-right pull-right">
					<?php if (mytheme_option('peta_link')):?>
						<?php $peta = mytheme_option('peta_link')?>
					<?php else:?>
						<?php $peta = "http://bukansekadarrokok.com/peta-boleh-merokok";?>
					<?php endif;?>

					<a href="<?php echo $peta ?>">PETA LOKASI BOLEH MEROKOK</a>
					
				</div>

			</div>

		</div>

		<!-- end of footer -->

	</div>

	<!-- start javascript plugin -->
	<!--[if lt IE 9]><script src="<?php bloginfo('template_directory'); ?>/js/html5ie.js"></script><![endif]-->
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.js"></script>
	<!-- script type="text/javascript" src="//code.jquery.com/ui/1.9.1/jquery-ui.js"></script-->
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/bootstrap.min.js"></script>	
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/iscroll-lite.js?v4"></script>
	<!-- end javascript plugin -->

	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jcarousellite_1.0.1.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/fancybox/jquery.fancybox.pack.js"></script>

	<script type="text/javascript">
		$(document).ready(function(){

			var myScroll = new iScroll('scrollWrapper',{bounce:false});

			var isMobile = {
			    Android: function() {
			        return navigator.userAgent.match(/Android/i);
			    },
			    BlackBerry: function() {
			        return navigator.userAgent.match(/BlackBerry/i);
			    },
			    iOS: function() {
			        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
			    },
			    Opera: function() {
			        return navigator.userAgent.match(/Opera Mini/i);
			    },
			    Windows: function() {
			        return navigator.userAgent.match(/IEMobile/i);
			    },
			    any: function() {
			        return (isMobile.Android() || isMobile.BlackBerry() || isMobile.iOS() || isMobile.Opera() || isMobile.Windows());
			    }
			};

			if( isMobile.BlackBerry() ) $("body").html('asu');

			$('#myCarousel').carousel({interval: 5000,pause:'hover'}).find('.item').eq(0).addClass('active');

			$('#myGalery').carousel({interval:false}).find('.item').eq(0).addClass('active');

			$('#myMerchandise').carousel({interval:false}).find('.item').eq(0).addClass('active');
			
			$('#merchandise-container').load("<?php bloginfo('template_directory'); ?>/merchandise.php");
			$('.tabs .nav-tabs li:first-child').addClass('active');
			$('.tabs .tab-pane:first-child').addClass('active');

			$('.komtek-menu-left a').click(
				function(){$("#kMenu").toggleClass('in');$(".komtek-mobile-body").toggleClass('push');}
			);
		});
		$(document).ready(function($){
		    $.ajaxSetup({cache:false});
		    $("a.merchandise-ctrl").click(function(){
		        var data = $(this).data("url");
		        $("a.merchandise-ctrl").removeClass('active');
		        $(this).addClass('active');
		    	$('#merchandise-container').load("<?php bloginfo('template_directory'); ?>/merchandise.php",{data_category:data});
		    	return false;
		    });
			
			$('#rss_externalfeed').each(function(){
				var url 	= '<?php bloginfo('template_directory'); ?>/rss-feed-external.php',
					feed 	= $(this).data('url'),
					baris	= $(this).data('baris');

				$(this).load(url,{feed_url:feed,baris:baris});
			});
			$('#rss_forumthread').each(function(){
				var url 	= '<?php bloginfo('template_directory'); ?>/rss-feed-forum.php',
					feed 	= $(this).data('url');

				$(this).load(url,{feed_url:feed});
			});
			$('.fancybox').fancybox({
				openEffect  : 'elastic',
				closeEffect	: 'elastic'
			});
					   	
		});
	</script>
	<script type="text/javascript">

	  var _gaq = _gaq || [];
	  _gaq.push(['_setAccount', 'UA-39765085-1']);
	  _gaq.push(['_trackPageview']);

	  (function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
	  })();

	</script>
</body>

</html>