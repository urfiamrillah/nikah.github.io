<?php include('header.php') ?>

		<div class="komtek-content-single">
			<?php 
			$args = array(
				'post_type' => 'gallery_photo',
			    'posts_per_page' => 8,
			    'paged' => ( get_query_var('paged') ? get_query_var('paged') : 1 ),
			);
			$gallery = new WP_Query( $args );
			?>
			<?php if ( $gallery->have_posts() ) : ?>
			<div class="undercat">

					<a href="#" style="text-transform:uppercase;background:#fff;padding-right:15px;">Gallery Photo</a>

					<hr/>

				</div>

			<div class="single-posts">
				<div class="post-summary">
					<br/>
					<ul class="gallery">
					<?php while ( $gallery->have_posts() ) : $gallery->the_post(); ?>

				
						<li>
							<div class="post-thumbnail">	
								<?php 
									$thumb = get_post_thumbnail_id(); 
						 			$image = vt_resize( $thumb,'' , 640, 480, true );
								?>
								<img title="<?php the_title(); ?>" class="gallery-thumbs fancybox" data-fancybox-group="gallery" href="<?php echo $image[url]; ?>" src="<?php echo $image[url]; ?>" width="<?php echo $image[width]; ?>" height="<?php echo $image[height]; ?>"/>
							</div>
						</li>

					<?php endwhile; ?>
					</ul>
				</div>
				<?php komtek_pagination($gallery->max_num_pages); ?>
			</div>
			
			<?php endif; ?>

		</div>

<?php include('footer.php') ?>