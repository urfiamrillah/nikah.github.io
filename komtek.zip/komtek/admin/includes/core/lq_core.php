<?php
function lq_themes_info() { 
	$lq_theme = wp_get_theme();
		$lqinfotheme = '<div class="format-setting-wrap"><div class="format-setting-label"><h3 class="label"><strong>System Information</strong></h3></div>';
		$lqinfotheme .= '<ul>';		
		$lqinfotheme .= '<li><strong>Theme Name:</strong> ' . $lq_theme->Name . '</li>';
	    $lqinfotheme .= '<li><strong>Theme Version:</strong> ' . $lq_theme->Version . '</li>';
		$lqinfotheme .= '<li><strong>Author:</strong> ' . $lq_theme->get( 'ThemeURI' ) . '</li>';
		$lqinfotheme .= '<li><strong>Home URL:</strong>' . home_url() . '</li>';
		$lqinfotheme .= '<li><strong>Site URL:</strong>' . site_url() . '</li>';
		if ( is_multisite() ) {
			$lqinfotheme .= '<li><strong>WordPress Version:</strong>' . 'WPMU ' . get_bloginfo('version') . '</li>';
		} else {
			$lqinfotheme .= '<li><strong>WordPress Version:</strong>'. 'WP ' . get_bloginfo('version') . '</li>';	
		}   	
		if ( function_exists( 'phpversion' ) ) {
			$lqinfotheme .= '<li><strong>PHP Version:</strong>' . esc_html( phpversion() ) . '</li>';
		}
		if (function_exists( 'size_format' )) {
			$lqinfotheme .= '<li><strong>Memory Limit:</strong>';
			$mem_limit = lq_let_to_num( WP_MEMORY_LIMIT );
			if ( $mem_limit < 67108864 ) {
				$lqinfotheme .= '<mark class="error">' . size_format( $mem_limit ) .' - Recommended memory to at least 64MB. Please see: <a href="http://codex.wordpress.org/Editing_wp-config.php#Increasing_memory_allocated_to_PHP" target="_blank">Increasing memory allocated to PHP</a></mark>';
			} else {
				$lqinfotheme .= '<mark class="yes">' . size_format( $mem_limit ) . '</mark>';
			}
			$lqinfotheme .= '</li>';
			$lqinfotheme .= '<li><strong>WP Max Upload Size:</strong>'. size_format( wp_max_upload_size() ) .' - Recommended is 2MB (Find tutorial about it in <a href="https://www.google.com/#q=WP+Max+Upload+Size" target="_blank">Google</a>)</li>';
		}
		if ( function_exists( 'ini_get' ) ) {
			$lqinfotheme .= '<li><strong>PHP Time Limit:</strong>'. ini_get('max_execution_time') .'</li>';
		}
		if ( defined('WP_DEBUG') && WP_DEBUG ) {
			$lqinfotheme .= '<li><strong>WP Debug Mode:</strong><mark class="yes"><b>Yes</b> - If life website please turn off WP debug mode. Please see: <a href="http://codex.wordpress.org/Debugging_in_WordPress" target="_blank">Debugging in WordPress</a></mark></mark></li>';
		} else {
			$lqinfotheme .= '<li><strong>WP Debug Mode:</strong><mark class="no">No</mark></li>';    
		}			
		$lqinfotheme .= '</ul></div>';
		$lqinfotheme .= '<div class="format-setting-wrap">';
	    $lqinfotheme .= '<div class="format-setting-label"><h3 class="label"><strong>Latest release themes from lq</strong></h3></div>';
	    $lqinfotheme .= $xml->lqlatestthemes;
		$lqinfotheme .= '</div>';
	return $lqinfotheme;
} 

function lq_let_to_num( $size ) {
    $let = substr( $size, -1 );
	$ret = substr( $size, 0, -1 );
        switch( strtoupper( $let ) ) {
     	case 'P':
     	    $ret *= 1024;
     	case 'T':
     	    $ret *= 1024;
     	case 'G':
     	    $ret *= 1024;
     	case 'M':
     	    $ret *= 1024;
     	case 'K':
     	    $ret *= 1024;
        }
    return $ret;
}
?>