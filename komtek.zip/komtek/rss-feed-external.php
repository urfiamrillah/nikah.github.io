<?php include '../../../wp-config.php' ?>

<?php
$feed_url = $_POST['feed_url'];
$baris = $_POST['baris'];

include_once(ABSPATH.WPINC.'/rss.php'); // path to include script
$feed = fetch_rss($feed_url); // specify feed url
$items = array_slice($feed->items, 0, 10); // specify first and last item
?>
<div id="externalfeed" class="feedburnerFeedBlock" data-baris="<?php echo $baris ?>">
	<ul>
<?php if (!empty($items)) : ?>
<?php foreach ($items as $item) : ?>
<li>
<span class="headline"><a href="<?php echo $item['link']; ?>"><?php echo $item['title']; ?></a></span>
<div style="height:60px;">
	<?php 
	$excerpt = $item['description'];
    $excerpt = strip_tags($excerpt);
    $excerpt = substr($excerpt, 0, 200);
	echo $excerpt. '...'; 
	?>
</div>
</li>
<?php endforeach; ?>
<?php endif; ?>
</ul>
</div>
<script type="text/javascript">
$("#externalfeed").jCarouselLite({
    speed: 500,
    visible:$("#externalfeed").data('baris'),
    vertical:true,
    auto:10000,
    hoverPause:true
});
</script>