<?php include '../../../wp-config.php' ?>
<script type="text/javascript">
$(function(){
	$('#myMerchandise').find('.item').eq(0).addClass('active');
});
</script>

<div class="carousel-inner">

	<?php 
	$category_slug = $_POST['data_category'];
	$args = array(
		'post_type' => 'merchandise',
		'merchandise_category' => $category_slug,
		'showposts' => 10,
	);
	$gallery = new WP_Query( $args ); 
	$i=0;
	while ($gallery->have_posts()) : $gallery->the_post();
	if($i%5==0) { ?>
	<div class="item">
	<?php } ?>
		<div class="item-merchandise">

			<div class="item-merchandise-cat">

				<?php
				$terms = get_the_terms( $post->ID , 'merchandise_category' );
				foreach ( $terms as $term ) {
				echo '<a href="index.php?merchandise_category='.$term->slug.'">'.$term->name.'</a>';
				}
					?>

				<div class="merchandise-arrow">&nbsp;</div>

			</div>

			<div class="item-merchandise-content" style="height:240px">

				<?php 
					$thumb = get_post_thumbnail_id(); 
				 	$image = vt_resize( $thumb,'' , 150, 210, true );
				 	$preview = vt_resize( $thumb,'' , 300, 370, true );
				?>
				<img class="fancybox" title="<?php the_title(); ?>" src="<?php echo $image[url]; ?>" href="<?php echo $preview[url]; ?>" width="<?php echo $image[width]; ?>" height="<?php echo $image[height]; ?>"/>

				<p class="merchandise-caption">

					<span class="caption-cat"><?php echo get_short_title(22); ?>...</span>

				</p>

			</div>

		</div>
		<?php $i++;
		if($i%5==0) { ?>
	</div>
	<?php } ?>
	<?php endwhile; ?>
	<?php
		if($i%5!=0) { ?>
	</div>
	<?php } ?>
</div>

					