<?php get_header(); ?>
	<?php if ( have_posts() ) : ?>
		<div class="komtek-content-single">

			<div class="single-post pull-left">

				<div class="undercat">
					<?php 
						$categories = get_the_category();
						foreach($categories as $category) {
							echo '<a href="'.get_category_link($category->cat_ID).'" style="text-transform:uppercase;text-decoration:none">'.$category->cat_name.'</a>';
						} 
					?>

					<hr/>

				</div>
				<?php while ( have_posts() ) : the_post(); ?>
				<div class="post-content" id="post-<?php the_ID(); ?>">

					<div class="post-title">

						<h1><a href="#"><?php the_title(); ?></a></h1>

						<span class="author">oleh: <?php the_author() ?></span>

					</div>

					<div class="post-entry">
						<?php the_content(); ?>
					</div>
				</div>
				<?php endwhile; ?>
			</div>

			<div class="single-sidebar pull-right">
				<?php get_sidebar(); ?>
			</div>

		</div>
	<?php endif; ?>
<?php include('footer.php') ?>
<?php /*
<?php include('header.php') ?>

		<div class="komtek-content-single">

			<div class="single-post pull-left">

				<div class="undercat">

					<a href="">OPINI</a>

					<hr/>

				</div>

				<div class="post-content">

					<div class="post-title">

						<h1><a href="">Bisnis dan Kuasa Pengetahuan dalam PP Tembakau</a></h1>

						<span class="author">by Rifqi Muhammad</span>

					</div>

					<div class="post-entry">

						<p>
							<img src="<?php bloginfo('template_directory'); ?>/exp_files/post1.jpg" class="alignleft" />
							Globalisasi telah mendorong arus pengetahuan dan transaksi perdagangan melintasi sekat negara-bangsa. Konsumen mendapati kebebasan untuk memilih jenis dan kualitas barang yang dihadirkan oleh pasar. Konsumen membaca semua informasi mengenai produk yang ia konsumsi. Namun informasi yang diproduksi oleh pemilik kuasa pengetahuan, itulah yang secara dominan dianggap benar. Proses inilah kemudian yang disebut-sebut akan membuat dunia menjadi seragam. Dalam konteks kebangsaan, globalisasi akan menghapus identitas dan cara pandang. Kebudayaan lokal, produk lokal, dan lebih jauh kearifan lokal, akan ditelan oleh kuasa global, yang dianggap lebih scientific.
						</p>

						<p>Saat ini, faktanya, sejak lahir sampai mati, kehidupan kita dikelilingi oleh pelbagai informasi-informasi dan dalil ilmiah. Pola ini semakin mempengaruhi berbagai segi kehidupan kita, lebih jauh mempengaruhi dan membentuk nilai dan budaya kita. Dalam konteks konsumsi, semakin banyak produk korporasi yang dilandasi oleh informasi scientific pula. Skema inilah yang banyak dimanfaatkan oleh korporasi asing untuk menyuburkan pasarnya di negeri ini.</p>

					</div>

				</div>

			</div>

			<div class="single-sidebar pull-right">

				<aside id="search" class="widget widget-search">

					<h3 class="widget-title">Search Form</h3>

					<input type="text" placeholder="Search" /><input type="submit" value="Search" />

				</aside>

				<aside id="categories" class="widget widget-categories">

					<h3 class="widget-title">Categories</h3>

					<ul>
						<li><a href="">Categories</a></li>
						<li><a href="">Categories New</a></li>
						<li><a href="">Categories Again</a></li>
						<li><a href="">Old Categories</a></li>
					</ul>

				</aside>

			</div>

		</div>

<?php include('footer.php') ?>
*/?>