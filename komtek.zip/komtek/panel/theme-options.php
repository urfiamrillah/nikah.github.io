<?php
/**
 * Initialize the custom Theme Options.
 */
add_action( 'admin_init', 'custom_theme_options', 1 );
//add_action( 'init', 'custom_theme_options' );


/**
 * Build the custom settings & update OptionTree.
 *
 * @return    void
 * @since     2.0
 */
function custom_theme_options() {

  /* OptionTree is not loaded yet, or this is not an admin request */
  if ( ! function_exists( 'ot_settings_id' ) || ! is_admin() )
    return false;

  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
    'contextual_help' => array( 
      'content'       => array( 
        array(
          'id'        => 'general_help',
          'title'     => __( 'General', 'lq_theme_textdomain' ),
          'content'   => '<p>' . __( 'Help content goes here!', 'lq_theme_textdomain' ) . '</p>'
        )
      ),
      'sidebar'       => '<p>' . __( 'Sidebar content goes here!', 'lq_theme_textdomain' ) . '</p>'
    ),
    /* 
    * LQ TABS admin
    */
    'sections'        => array( 
      array(
        'title'       => __( 'General', lq_theme_textdomain ),
        'id'          => 'general_tab'
      ),
      array(
        'title'       => __( 'System Information', lq_theme_textdomain ),
        'id'          => 'themeinfo_tab'
      ),
    ),
    /* 
    * LQ General settings
    */
    'settings'        => array( 
      array(
        'id'          => 'demo_background',
        'label'       => __( 'Background', 'lq_theme_textdomain' ),
        'desc'        => sprintf( __( 'The Background option type is for adding background styles to your theme either dynamically via the CSS option type below or manually with %s. The Background option type has filters that allow you to remove fields or change the defaults. For example, you can filter %s to remove unwanted fields from all Background options or an individual one. You can also filter %s. These filters allow you to fine tune the select lists for your specific needs.', 'lq_theme_textdomain' ), '<code>ot_get_option()</code>', '<code>ot_recognized_background_fields</code>', '<code>ot_recognized_background_repeat</code>, <code>ot_recognized_background_attachment</code>, <code>ot_recognized_background_position</code>, ' . __( 'and', 'lq_theme_textdomain' ) . ' <code>ot_type_background_size_choices</code>' ),
        'std'         => '',
        'type'        => 'background',
        'section'     => 'general_tab',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'label'       => __( 'System information', lq_theme_textdomain ),
        //'id'          => 'lq_textblock',
        'type'        => 'textblock',
        'desc'        => lq_themes_info(),
        'section'     => 'themeinfo_tab'
      ),
    )
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;
  
}