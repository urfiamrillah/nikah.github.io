<?php
    /********************/
    /* Add Theme Option */
    /********************/
    add_filter('ot_show_pages', '__return_false');
    add_filter('ot_show_new_layout', '__return_false');
    add_filter('ot_theme_mode', '__return_true');
    add_filter('ot_theme_options_parent_slug', '__return_false');
    include_once('admin/includes/core/lq_core.php');
    include_once('admin/ot-loader.php');
    include_once('panel/meta-boxes.php');
    include_once('panel/theme-options.php');

	
    // Add RSS links to <head> section
	automatic_feed_links();
	
	// Clean up the <head>
	function removeHeadLinks() {
    	remove_action('wp_head', 'rsd_link');
    	remove_action('wp_head', 'wlwmanifest_link');
    }
    add_action('init', 'removeHeadLinks');
    remove_action('wp_head', 'wp_generator');
    
    if (function_exists('register_sidebar')) {
    	register_sidebar(array(
    		'name' => 'Sidebar Widgets',
    		'id'   => 'sidebar-widgets',
    		'description'   => 'These are widgets for the sidebar.',
    		'before_widget' => '<div id="%1$s" class="widget %2$s">',
    		'after_widget'  => '</div>',
    		'before_title'  => '<h2>',
    		'after_title'   => '</h2>'
    	));
    }
    
    add_theme_support('post-thumbnails');


    function hook_excerpt_featured_length($length) {
		return 30;
	}
	function slideshow_featured_posts() {
		wp_reset_query();
		$featured = 1; 
		$count = 5; 
		add_filter('excerpt_length', 'hook_excerpt_featured_length');
	}
    function get_short_post($limit){
        $excerpt = get_the_content();
        $excerpt = strip_shortcodes($excerpt);
        $excerpt = strip_tags($excerpt);
        $the_str = substr($excerpt, 0, $limit);
        return $the_str;
    }
    function get_short_title($limit){
        $title = get_the_title();
        $title = strip_shortcodes($title);
        $title = strip_tags($title);
        $the_str = substr($title, 0, $limit);
        return $the_str;
    }

    include(TEMPLATEPATH . '/lib/theme-options.php');
    include(TEMPLATEPATH . '/lib/vt_resize.php');
    include(TEMPLATEPATH . '/lib/galeri-photo.php');
    include(TEMPLATEPATH . '/lib/pagination.php');
    include(TEMPLATEPATH . '/lib/merchandise.php');
    include(TEMPLATEPATH . '/lib/youtube.php');
    include(TEMPLATEPATH . '/lib/shortcodes.php');
?>