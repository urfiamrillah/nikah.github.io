<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<!--[if lt IE 7 ]> <html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US" class="no-js"><!--<![endif]-->

<head>
	<link href="<?php bloginfo('template_directory'); ?>/img/logo.png" rel="icon" type="image/x-icon"/>
	<link rel="profile" href="http://gmpg.org/xfn/11" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="generator" content="rahendzapp" />
	<meta name="version" content="0.1" />
	<title>Komunitas Kretek</title>
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/bootstrap-responsive.min.css" />
	<!--[if IE]><link rel="stylesheet" type="text/css" href="css/jqueryuiie.css"/><![endif]-->
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/jqueryui.css">
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/css/rahendz.css">
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css">
	<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/fancybox/jquery.fancybox.css">
	<meta http-equiv="cache-control" content="no-cache" />
	<meta http-equiv="pragma" content="no-cache" />

	<script type="text/javascript">

//	var myScroll;
//	function loaded() {
//		myScroll = new iScroll('scrollWrapper',{bounce:false});
//	}

//	document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);

//	document.addEventListener('DOMContentLoaded', loaded, false);

	</script>
	<?php wp_head(); ?> 
</head>

<body class="body-wrapper">

	<div id="kMenu" class="komtek-mobile-menu">

		<div class="mobile-menu-search">
			<form>
				<input type="text" placeholder="SEARCH" />
				<input type="submit" value="" />
			</form>
		</div>

		<div id="scrollWrapper">

			<div id="scroller">
			
				<div class="mobile-menu-list">
					<h3>Favorit</h3>
					<ul>
						<li><a href="./forum">Forum Kretekus</a></li>
						<li><a href="index.php">Komunitas Kretek</a></li>
						<li><a href="index.php?page_id=151">Bukan Sekedar Merokok</a></li>
					</ul>
					<h3>Menu</h3>
					<ul>
						<li><a href="index.php?cat=5">Opini</a></li>
						<li><a href="index.php?cat=9">Kegiatan</a></li>
						<li><a href="index.php?cat=14">Kanal Berita</a></li>
						<li><a href="index.php?cat=36">Ragam</a></li>
						<li><a href="index.php?post_type=gallery_photo">Galeri Foto</a></li>
						<li><a href="index.php?post_type=video">Galeri Video</a></li>
					</ul>
					<h3>Social</h3>
					<ul>
						<li><a href="https://twitter.com/KomunitasKretek">Twitter</a></li>
						<li><a href="http://www.facebook.com/pages/Komunitas-Kretek/279628405420047">Facebook</a></li>
						<li><a href="http://matkretek.blogspot.com/">Chirpstory</a></li>
						<li><a href="http://www.youtube.com/user/KomunitasKretek">Youtube</a></li>
						<li><a href="http://bukansekadarrokok.com/peta-boleh-merokok">Lokasi Boleh Merokok</a></li>
					</ul>
				</div>

				<div class="mobile-menu-contact">
					<h4>Sekretariat</h4>
					<p>
						Jalan Anggajaya 1 Gang Rajawali No. 180 Condong Catur Sleman Yogyakarta
					</p>
					<p><strong>Telepon/Fax :</strong> 0274 4463054</p>
					<p><strong>Email :</strong> media.komtek@gmail.com</p>
				</div>

				<div class="mobile-menu-copyright">
					<p>Copyright &copy; 2010 <a href="index.php">Komunitas Kretek</a></p>
					<p>All rights reserved</p>
				</div>

			</div>

		</div>

	</div>

	<div class="komtek-mobile-body">

	<div class="navbar navbar-fixed-top">
		<div class="navbar-inner komtek-navbar">
			<ul class="nav komtek-navbar-left pull-left">
				<li><a href="index.php">Komunitas Kretek</a></li>
			</ul>
			<ul class="nav komtek-menu-left pull-left hide">
				<li><a>&nbsp;</a></li>
			</ul>
			<a href="index.php"><img src="<?php bloginfo('template_directory'); ?>/img/logo.png" /></a>
			<ul class="nav komtek-navbar-right pull-right">
				<li><a href="./forum">Forum Kretekus</a></li>
			</ul>
			<ul class="nav komtek-menu-right pull-right hide">
				<li><a href="#">&nbsp;</a></li>
			</ul>
		</div>
		<div class="komtek-logo-wrapper">&nbsp;</div>
		<div class="navbar-inner komtek-menu">
			<div class="komtek-menu-inner">
			<ul class="nav komtek-menu-left pull-left">
				<li><a href="index.php?cat=5">OPINI</a></li>
				<li><a href="index.php?cat=9">KEGIATAN</a></li>
			</ul>
			<ul class="nav komtek-menu-right pull-right">
				<li><a href="index.php?cat=14">KANAL BERITA</a></li>
				<li><a href="index.php?cat=36">RAGAM</a></li>
			</ul>
			</div>
		</div>
	</div>

	<div class="komtek-content">
