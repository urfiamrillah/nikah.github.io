<?php include '../../../wp-config.php' ?>

<?php
$feed_url = $_POST['feed_url'];

include_once(ABSPATH.WPINC.'/rss.php'); // path to include script
$feed = fetch_rss($feed_url); // specify feed url
$items = array_slice($feed->items, 0, 10); // specify first and last item
?>
<div id="forumfeed" class="feedburnerFeedBlock">
	<ul>
<?php if (!empty($items)) : ?>
<?php foreach ($items as $item) : ?>
<li>
<span class="headline"><a href="<?php echo $item['link']; ?>"><?php echo $item['title']; ?></a></span>
<div style="height:60px;">
	<?php 
	$excerpt = $item['description'];
    $excerpt = strip_tags($excerpt);
    $excerpt = substr($excerpt, 0, 200);
	echo $excerpt. '...'; 
	?>
</div>
</li>
<?php endforeach; ?>
<?php endif; ?>
</ul>
</div>
<script type="text/javascript">
$("#forumfeed").jCarouselLite({
    speed: 500,
    visible:1,
    auto:15000,
    hoverPause:true
});
</script>