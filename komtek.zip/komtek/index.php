<?php include('header.php') ?>
		
		<!-- start Slide -->
		<?php get_template_part('slideshow'); ?>
		<!-- end of slide -->

		<!-- Start Opini -->
		<div id="kOpini" class="content-opini-wrapper">

			<div class="content-opini">

				<div class="content-title opini-title">

					<a href="index.php?cat=5">OPINI</a><hr/>

				</div>

				<div class="featured-opini pull-left">

					<?php query_posts('cat=5&showposts=1'); ?>
					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<div class="featured-title-wrapper">
						<?php 
							$thumb = get_post_thumbnail_id(); 
						 	$image = vt_resize( $thumb,'' , 300, 123, true );
						?>
 						<img src="<?php echo $image[url]; ?>" width="<?php echo $image[width]; ?>" height="<?php echo $image[height]; ?>" class="featured-title-image"/>
						<h3 class="featured-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					</div>

					<div class="featured-author pull-left">
						<img src="<?php bloginfo('template_directory'); ?>/exp_files/author.jpg" />
						<p>by <?php the_author_posts_link(); ?></p>
					</div>

					<div class="featured-post pull-right">
						<p><?php echo get_short_post(250) .'...' ?></p>
					</div>
					<?php endwhile; else: ?>Oops<?php endif; ?>

				</div>

				<div class="other-opini pull-right">
					<?php query_posts('cat=5&showposts=3&offset=1'); ?>
					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
					<div class="other-opini-post">
						<div class="other-opini-thumbnail pull-left">
							<?php the_post_thumbnail('thumbnail'); ?>
						</div>
						<div class="other-opini-title pull-right">
							<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<span class="other-opini-author">by <?php the_author_posts_link(); ?></span>
						</div>
						<div class="other-opini-content pull-right">
							<p><?php echo get_short_post(90) .'...' ?></p>
						</div>
					</div>
					<?php endwhile; else: ?>Oops<?php endif; ?>
				</div>

			</div>

		</div>

		<!-- end of opini -->

		<div id="kKegiatanBerita" class="content-kegiatanberita-wrapper" style="overflow:hidden">

			<div class="content-kegiatanberita">

				<div class="content-kegiatan-wrapper pull-left">

					<div class="content-title kegiatan-title">

						<a href="index.php?cat=9" style="background:#612111;padding-right:15px;font-size:30px;">KEGIATAN</a><hr/>

					</div>

					<div class="content-kegiatan">
						<?php query_posts('cat=9&showposts=1'); ?>
						<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
						<div class="content-kegiatan-title" style="min-height:60px;">

							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

							<span class="content-kegiatan-date"><?php the_date(); ?></span>

						</div>

						<div class="content-kegiatan-thumbnail featured">

							<?php 
								$thumb = get_post_thumbnail_id(); 
							 	$image = vt_resize( $thumb,'' , 450, 180, true );
							?>
							<img src="<?php echo $image[url]; ?>" width="<?php echo $image[width]; ?>" height="<?php echo $image[height]; ?>" style="width:100%;"/>

						</div>

						<div class="content-kegiatan-post">

							<p><?php echo get_short_post(200) .'...' ?></p>

						</div>
						<?php endwhile; else: ?>Oops<?php endif; ?>
						<div class="content-kegiatan-related">

							<h3>Lainnya di <a href="index.php?cat=9">Kegiatan</a> :</h3>

							<ul>
								<?php query_posts('cat=5&showposts=3&offset=1'); ?>
								<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
								<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
								<?php endwhile; else: ?>Oops<?php endif; ?>
							</ul>

						</div>

					</div>

				</div>

				<div class="content-berita-wrapper pull-right">

					<div class="content-title kegiatan-title">

						<a href="index.php?cat=14" style="background:#612111;padding-right:15px;font-size:30px;">KANAL BERITA</a><hr/>

					</div>

					<div class="content-kegiatan">
						<?php query_posts('cat=14&showposts=1'); ?>
						<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
						<div class="content-kegiatan-title" style="min-height:60px;">

							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

							<span class="content-kegiatan-date"><?php the_date(); ?></span>

						</div>

						<div class="content-kegiatan-thumbnail">

							<?php 
								$thumb = get_post_thumbnail_id(); 
							 	$image = vt_resize( $thumb,'' , 450, 180, true );
							?>
							<img src="<?php echo $image[url]; ?>" width="<?php echo $image[width]; ?>" height="<?php echo $image[height]; ?>" style="width:100%;"/>

						</div>

						<div class="content-kegiatan-post">

							<p><?php echo get_short_post(200) .'...' ?></p>

						</div>
						<?php endwhile; else: ?>Oops<?php endif; ?>
						<div class="content-kegiatan-related">

							<h3>Lainnya di <a href="index.php?cat=9">Kanal Berita</a> :</h3>

							<ul>
								<?php query_posts('cat=14&showposts=3&offset=1'); ?>
								<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
								<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
								<?php endwhile; else: ?>Oops<?php endif; ?>
							</ul>

						</div>

					</div>

				</div>

			</div>

		</div>

		<!-- end of kegiatan dan kanal berita -->

		<div id="kRagam" class="content-ragam-wrapper">

			<div class="content-ragam">

				<div class="content-title ragam-title">

					<a href="index.php?cat=36" style="background:#8a716b;padding-right:15px;">RAGAM</a><hr/>

				</div>

				<div class="content-ragam-post-wrapper">

					<?php query_posts('cat=36&showposts=3'); ?>
					<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

					<div class="content-ragam-posts">

						<div class="content-ragam-title" style="min-height:70px;">

							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

							<span class="content-ragam-author author dark">oleh <?php the_author_posts_link(); ?>  </span>

						</div>

						<div class="content-ragam-thumbnail featured">

							<?php 
								$thumb = get_post_thumbnail_id(); 
							 	$image = vt_resize( $thumb,'' , 300, 100, true );
							?>
							<img src="<?php echo $image[url]; ?>" width="<?php echo $image[width]; ?>" height="<?php echo $image[height]; ?>" style="width:100%;"/>

						</div>

						<div class="content-ragam-post">

							<p><?php echo get_short_post(150) .'...' ?></p>

						</div>

					</div>
					<?php endwhile; else: ?>Oops<?php endif; ?>

				</div>

				<div class="content-ragam-catlink">Lainnya di <a href="index.php?cat=36">Ragam &rsaquo;</a></div>

			</div>

		</div>
		
		<!-- end of ragam -->

		<div id="kGaleri" class="content-galeri-wrapper">

			<div class="content-galeri">

				<div class="content-title galeri-title">

					<a href="index.php?post_type=gallery_photo">GALERI FOTO</a><hr/>

				</div>

				<div id="myGalery" class="content-galeri-post galeri-slide carousel slide">

					<div class="carousel-inner">
						<?php
							$args = array(
								'post_type' => 'gallery_photo',
								'showposts' => 36
							);
							$gallery = new WP_Query( $args );
							if( $gallery->have_posts() ) {
								$i=0;
								while( $gallery->have_posts() ) {
									$gallery->the_post();
									?>
									<?php if($i%9==0) { ?>
									<div class="item">
									<?php } ?>
										<?php 
											$thumb = get_post_thumbnail_id(); 
								 			$image = vt_resize( $thumb,'' , 640, 480, true );
										?>
										<img class="img-galeri fancybox" data-fancybox-group="gallery" title="<?php the_title(); ?>" href="<?php echo $image[url]; ?>" src="<?php echo $image[url]; ?>" width="<?php echo $image[width]; ?>" height="<?php echo $image[height]; ?>"/>
									<?php $i++; if($i%9==0) { ?>
									</div>
									<?php } ?>
									<?php
								}
								?>
								<?php
									if($i%9!=0) { 9 ?>
								</div>
								<?php } ?>
							<?php 
							}
							else {
								echo 'oOops no products!';
							}
						?>
					</div>

					<a class="galeri-control pull-left" href="#myGalery" data-slide="prev" onclick="return false">&lsaquo;</a>
					<a class="galeri-control pull-right" href="#myGalery" data-slide="next" onclick="return false">&rsaquo;</a>

				</div>

			</div>

		</div>

		<!-- end of galeri -->
		<div id="kMerchandise" class="content-merchandise-wrapper">

			<div class="content-merchandise">

				<div class="content-title merchandise-title">

					<a href="index.php?post_type=merchandise">MERCHANDISE</a><hr/>

				</div>

				<div id="myMerchandise" class="content-merchandise-post merchandise-slide carousel slide" style="min-height:300px;">
					<div id="merchandise-container">

					</div>
					<br/>
					<a class="merchandise-control left" href="#myMerchandise" data-slide="prev">&lsaquo;</a>
					<a class="merchandise-control right" href="#myMerchandise" data-slide="next">&rsaquo;</a>
					<span class="merchandise-catlink pull-right" style="position:absolute;bottom:-30px;right:0px;">
						<?php
							$taxonomy = 'merchandise_category';
							$tax_terms = get_terms($taxonomy);
						?>
						<a href="#" class="merchandise-ctrl" data-url="">Semua Merchandise</a> |
						<?php
							foreach ($tax_terms as $tax_term) {
							echo '<a class="merchandise-ctrl" href="#" data-url="'. $tax_term->slug.'">' . $tax_term->name.'</a> |';
						}
						?>
					</span>
				</div>

			</div>

		</div>

		<!-- end of merchandise -->

		<div id="kVideo" class="content-videofeed-wrapper">

			<div class="content-videofeed">

				<div class="content-video pull-left">

					<div class="content-title video-title">

						<a href="index.php?post_type=video">VIDEO</a><hr/>

					</div>
					<?php 
						$args = array(
							'post_type' => 'video',
					    	'showposts' => 1
						);
						$gallery = new WP_Query( $args );
					?>
					<?php if ( $gallery->have_posts() ) : while ( $gallery->have_posts() ) : $gallery->the_post(); ?>
					<div class="content-video-post">
						<?php 
						$videoid = parse_yturl(get_post_meta(get_the_ID(), '_yt_video', true));
						echo '<iframe src="http://www.youtube.com/embed/'.$videoid.'" frameborder="0" allowfullscreen></iframe>';  
						?>
					</div>
					<?php endwhile; else: ?>Belum ada Post<?php endif; ?>
				</div>

				<div class="content-feed pull-right">
					<?php if (mytheme_option('rss_title') && mytheme_option('rss_title_link') && mytheme_option('rss_link') && mytheme_option('rss_baris')):?>
						<?php $title = mytheme_option('rss_title')?>
						<?php $title_link = mytheme_option('rss_title_link')?>
						<?php $link = mytheme_option('rss_link')?>
						<?php $baris = mytheme_option('rss_baris')?>
					<?php else:?>
						<?php $title = "MEMBUNUHINDONESIA.COM";?>
						<?php $title_link = "http://membunuhindonesia.com";?>
						<?php $link = "http://membunuhindonesia.com/feed";?>
						<?php $baris = "2";?>
					<?php endif;?>

					<div class="content-title feed-title">

						<a href="<?php echo $title_link ?>" target="_blank"><?php echo $title ?></a><hr/>
					</div>

					
					<div id="rss_externalfeed" data-url="<?php echo $link ?>" data-baris="<?php echo $baris ?>">
						
					</div>
				</div>

			</div>

		</div>		

		<!-- end of video -->

		<div id="kFeed" class="content-feedforum-wrapper">

			<div class="content-feedforum">

				<div class="content-feedforum-title pull-left">

					<a href="./forum" target="_blank">FORUM KRETEKUS</a>

				</div>

				<div class="content-feedforum-post pull-right">
					<?php if (mytheme_option('rss_forum')):?>
						<?php $link = mytheme_option('rss_forum')?>
					<?php else:?>
						<?php $link = "http://komunitaskretek.or.id/forum/syndication.php";?>
					<?php endif;?>
					<div id="rss_forumthread" data-url="<?php echo $link ?>">
						
					</div>

				</div>

			</div>

		</div>

		<!-- end of feed -->

<?php include('footer.php') ?>