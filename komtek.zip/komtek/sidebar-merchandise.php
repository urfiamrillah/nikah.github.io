<aside id="search" class="widget widget-search">

    <h3 class="widget-title">Search Form</h3>
    <form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
        <input type="text" id="s" name="s" value="" placeholder="Search" /><input type="submit" value="Search" />
    </form>

</aside>

<aside id="categories" class="widget widget-categories">

    <h3 class="widget-title">Merchandise</h3>

    <?php
		$taxonomy = 'merchandise_category';
		$tax_terms = get_terms($taxonomy);
	?>
	<ul>
		<li><a href="index.php?post_type=merchandise">Semua Merchandise</a></li>
	<?php
		foreach ($tax_terms as $tax_term) {
		echo '<li>' . '<a href="' . esc_attr(get_term_link($tax_term, $taxonomy)) . '" title="' . sprintf( __( "View all posts in %s" ), $tax_term->name ) . '" ' . '>' . $tax_term->name.'</a></li>';
	}
	?>
	</ul>

</aside>