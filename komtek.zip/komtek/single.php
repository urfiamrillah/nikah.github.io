<?php get_header(); ?>
	<?php if ( have_posts() ) : ?>
		<div class="komtek-content-single">

			<div class="single-post pull-left">

				<div class="undercat">
					<?php 
						$categories = get_the_category();
						foreach($categories as $category) {
							echo '<a href="'.get_category_link($category->cat_ID).'" style="text-transform:uppercase;text-decoration:none;background:#fff;padding-right:15px">'.$category->cat_name.'</a>';
						} 
					?>

					<hr/>

				</div>
				<?php while ( have_posts() ) : the_post(); ?>
				<div class="post-content" id="post-<?php the_ID(); ?>">

					<div class="post-title">

						<h1><a href="#"><?php the_title(); ?></a></h1>

						<span class="author">oleh: <?php the_author() ?></span>

					</div>

					<div class="post-entry">
						<?php the_content(); ?>
					</div>
				</div>
				<?php endwhile; ?>
			</div>

			<div class="single-sidebar pull-right">
				<?php get_sidebar(); ?>
			</div>

		</div>
	<?php endif; ?>
<?php include('footer.php') ?>