<aside id="search" class="widget widget-search">

    <h3 class="widget-title">Search Form</h3>
    <form action="<?php bloginfo('siteurl'); ?>" id="searchform" method="get">
        <input type="text" id="s" name="s" value="" placeholder="Search" /><input type="submit" value="Search" />
    </form>

</aside>

<aside id="categories" class="widget widget-categories">

    <ul class="nav nav-tabs">
        <li class="active"><a href="#opini-tab" data-toggle="tab">Opini</a></li>
        <li><a href="#kegiatan-tab" data-toggle="tab">Kegiatan</a></li>
    </ul>
    <div class="tab-content" style="padding-right:15px;">
        <div class="tab-pane active" id="opini-tab">            
            <ul>
            <?php query_posts('cat=5&showposts=5'); ?>
            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
            <?php endwhile; else: ?>Oops<?php endif; ?>
            </ul>
        </div>
        <div class="tab-pane" id="kegiatan-tab">
            <ul>
            <?php query_posts('cat=9&showposts=5'); ?>
            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
            <?php endwhile; else: ?>Oops<?php endif; ?>
            </ul>
        </div>
    </div>
    <ul class="nav nav-tabs">
        <li class="active"><a href="#kanal-tab" data-toggle="tab">Kanal Berita</a></li>
        <li><a href="#ragam-tab" data-toggle="tab">Ragam</a></li>
    </ul>
    <div class="tab-content" style="padding-right:15px;">
        <div class="tab-pane active" id="kanal-tab">            
            <ul>
            <?php query_posts('cat=14&showposts=5'); ?>
            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
            <?php endwhile; else: ?>Oops<?php endif; ?>
            </ul>
        </div>
        <div class="tab-pane" id="ragam-tab">
            <ul>
            <?php query_posts('cat=36&showposts=5'); ?>
            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
                <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
            <?php endwhile; else: ?>Oops<?php endif; ?>
            </ul>
        </div>
    </div>
</aside>