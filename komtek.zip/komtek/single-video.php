<?php get_header(); ?>
	<?php if ( have_posts() ) : ?>
		<div class="komtek-content-single">

			<div class="single-posts">
				<div class="undercat">
					<a href="index.php?post_type=video" style="background:#fff;padding:0 15px;">GALLERY VIDEO</a>

					<hr/>

				</div>
				<?php while ( have_posts() ) : the_post(); ?>
				<div class="post-content" id="post-<?php the_ID(); ?>" style="margin-right:40px;">

					<div class="post-title">

						<h1><a href="#"><?php the_title(); ?></a></h1>

						<span class="author">oleh: <?php the_author() ?></span>

					</div>

					<div class="post-entry">
						<?php 
						$videoid = parse_yturl(get_post_meta(get_the_ID(), '_yt_video', true));
						echo '<iframe width="100%" height="600" src="http://www.youtube.com/embed/'.$videoid.'" frameborder="0" allowfullscreen></iframe>';  
						?>
						<br/><br/>
						<?php the_content(); ?>
					</div>
				</div>
				<?php endwhile; ?>
			</div>
		</div>
	<?php endif; ?>
<?php include('footer.php') ?>