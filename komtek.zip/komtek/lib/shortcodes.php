<?php
// Twitter Bootstrap Tabs grabbed from www.friiitz.com
// Exampe Use :
// [tabgroup]
// [tab state="active" title="Tab1"]Content of Tab 1[/tab]
// [tab title="Tab2"]Content of Tab 2[/tab]
// [/tabgroup]

add_shortcode( 'tabgroup', 'tabgroup' );
function tabgroup( $atts, $content ){
$GLOBALS['tab_count'] = 0;

do_shortcode( $content );

if( is_array( $GLOBALS['tabs'] ) ){
foreach( $GLOBALS['tabs'] as $tab ){
$tabs[] = '<li><a href="#'.$tab['id'].'" data-toggle="tab">'.$tab['title'].'</a></li>';
$panes[] = '<div class="tab-pane" id="'.$tab['id'].'">'.$tab['content'].'</div>';
}
$return = "\n".'<div class="tabs"><ul class="nav nav-tabs">'.implode( "\n", $tabs ).'</ul>'."\n".'<div class="tab-content">'.implode( "\n", $panes ).'</div></div>'."\n";
}
return $return;
}

add_shortcode( 'tab', 'tabs' );
function tabs( $atts, $content ){
extract(shortcode_atts(array(
'id'    => 'Tab %d',
'title' => 'Tab %d',
'state' => ''
), $atts));

$x = $GLOBALS['tab_count'];
$GLOBALS['tabs'][$x] = array( 'id' => sprintf( $id, $GLOBALS['tab_count'] ), 'title' => sprintf( $title, $GLOBALS['tab_count'] ), 'state' => sprintf( $state, $GLOBALS['tab_count'] ), 'content' =>  $content );

$GLOBALS['tab_count']++;
}
?>