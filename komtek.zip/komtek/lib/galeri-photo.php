<?php
    function gallery_photo() {
        $labels = array(
            'name'               => _x( 'Photo Gallery', 'post type general name' ),
            'singular_name'      => _x( 'Photo Gallery', 'post type singular name' ),
            'add_new'            => _x( 'Add New', 'photo' ),
            'add_new_item'       => __( 'Add New Photo' ),
            'edit_item'          => __( 'Edit Photo' ),
            'new_item'           => __( 'New Photo' ),
            'all_items'          => __( 'All Photos' ),
            'view_item'          => __( 'View Photo' ),
            'search_items'       => __( 'Search Photo' ),
            'not_found'          => __( 'No Photos found' ),
            'not_found_in_trash' => __( 'No Photos found in the Trash' ), 
            'parent_item_colon'  => '',
            'menu_name'          => 'Photo Gallery'
        );
        $args = array(
            'labels'        => $labels,
            'description'   => 'Gallery Photo Komunitas Komtek',
            'public'        => true,
            'menu_position' => 25,
            'show_ui'       => true,
            'capability_type' => 'post',
            'hierarchical'  => false,
            'rewrite'       => true,
            'query_var'     => true,
            'supports'      => array( 'title', 'editor', 'thumbnail', 'comments', 'page-attributes'),
            'menu_icon'     => get_stylesheet_directory_uri()  . '/img/camera.png',
            'has_archive'   => true,
            'taxonomies'    =>  array('post_tag'),
            'show_in_menu'  =>  true
        );
        register_post_type( 'gallery_photo', $args ); 
    }
    add_action( 'init', 'gallery_photo' );

    function gallery_photo_get_featured_image($post_ID) {  
        $post_thumbnail_id = get_post_thumbnail_id($post_ID);  
        if ($post_thumbnail_id) {  
            $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'featured_preview');  
            return $post_thumbnail_img[0];  
        }  
    }  
        // ADD NEW COLUMN  
    function gallery_photo_columns_head($defaults) {  
        $new_columns['cb'] = '<input type="checkbox" />';
        
        $new_columns['featured_image'] = ('Photo');
        $new_columns['title'] = _x('Title', 'column name');
        $new_columns['tags'] = _x('tags', 'tags name');
     
        $new_columns['date'] = _x('Date', 'column name');
     
        return $new_columns;
        //$defaults['featured_image'] = 'Photo';  
        //return $defaults;  
    }  
      
    // SHOW THE FEATURED IMAGE  
    function gallery_photo_columns_content($column_name, $post_ID) {  
        if ($column_name == 'featured_image') {  
            $post_featured_image = gallery_photo_get_featured_image($post_ID);  
            if ($post_featured_image) {  
                echo '<div class="thumbnail" style="width:50px;height:50px;overflow:hidden;""><img src="' . $post_featured_image . '" style="height:50px;"/></div>';  
            }  
        }  
    }  

    add_filter('manage_gallery_photo_posts_columns', 'gallery_photo_columns_head');  
    add_action('manage_gallery_photo_posts_custom_column', 'gallery_photo_columns_content', 10, 2);

    add_action('admin_head', 'gallery_photo_style');

    function gallery_photo_style() {
        echo '<style type="text/css">';
        echo '.column-featured_image { width:60px;text-align:center; }';
        echo '</style>';
    }

    add_filter( 'template_include', 'include_template_function', 1 );

    function include_template_function( $template_path ) {
        if ( get_post_type() == 'gallery_photo' ) {
            if ( is_single() ) {
                // checks if the file exists in the theme first,
                // otherwise serve the file from the plugin
                if ( $theme_file = locate_template( array ( 'single-gallery_photo.php' ) ) ) {
                    $template_path = $theme_file;
                } else {
                    $template_path = plugin_dir_path( __FILE__ ) . '/single-gallery_photo.php';
                }
            }
        }
        return $template_path;
    }
?>