<?php
    add_action( 'init', 'create_post_type_video' );

function create_post_type_video() {

    $labels = array(
        'name'               => _x( 'Youtube', 'post type general name' ),
        'singular_name'      => _x( 'Youtube', 'post type singular name' ),
        'add_new'            => _x( 'Add New', 'video' ),
        'add_new_item'       => __( 'Add New Video' ),
        'edit_item'          => __( 'Edit Video' ),
        'new_item'           => __( 'New Video' ),
        'all_items'          => __( 'All Videos' ),
        'view_item'          => __( 'View Video' ),
        'search_items'       => __( 'Search Video' ),
        'not_found'          => __( 'No Videos found' ),
        'not_found_in_trash' => __( 'No Videos found in the Trash' ), 
        'parent_item_colon'  => '',
        'menu_name'          => 'Youtube'
    );

    register_post_type( 'video', array(
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'has_archive' => 'videos',
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => null,
        'supports' => array('title','editor','thumbnail'),
        'menu_icon'     => get_stylesheet_directory_uri()  . '/img/youtube-icon.png',
        )
    );


}

add_action( 'add_meta_boxes', 'video_add_meta_box' );

function video_add_meta_box() {
    add_meta_box(
        'video_metaboxid',
        'Link Video',
        'video_inner_meta_box',
        'video'
    );
}

function video_inner_meta_box( $video ) {
?>
  <label for="realizador">Youtube:</label>
  <br />
  <input type="text" name="yt_video" style="width:100%" value="<?php echo get_post_meta( $video->ID, '_yt_video', true ); ?>" />
  <br/>
  <em>example: <strong>http://www.youtube.com/watch?v=def8pFsc6b4</strong></em>
<?php
}

add_action( 'save_post', 'ewp_video_save_post', 10, 2 );

function ewp_video_save_post( $video_id, $video ) {

   if ( ! $_POST['yt_video'] ) return;

   update_post_meta( $video_id, '_yt_video', strip_tags( $_POST['yt_video'] ) );

   return true;

}

function parse_yturl($url) 
{
    $pattern = '#^(?:https?://)?(?:www\.)?(?:youtu\.be/|youtube\.com(?:/embed/|/v/|/watch\?v=|/watch\?.+&v=))([\w-]{11})(?:.+)?$#x';
    preg_match($pattern, $url, $matches);
    return (isset($matches[1])) ? $matches[1] : false;
}
?>