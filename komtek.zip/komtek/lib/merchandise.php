<?php
    function merchandise() {
        $labels = array(
            'name'               => _x('Merchandise','post type general name'),
            'singular_name'      => _x('Merchandise','post type singular name'),
            'add_new'            => _x('Add New','merchandise'),
            'add_new_item'       => __('Add New Merchandise'),
            'edit_item'          => __('Edit Merchandise'),
            'new_item'           => __('New Merchandise'),
            'all_items'          => __('All Merchandise'),
            'view_item'          => __('View Merchandise'),
            'search_items'       => __('Search Merchandise'),
            'not_found'          => __('No Merchandise found'),
            'not_found_in_trash' => __('No Merchandise found in the Trash'),
            'parent_item_colon'  => '',
            'menu_name'          => 'Merchandise'
       );
        $args = array(
            'labels'        => $labels,
            'description'   => 'Merchandise Komunitas Komtek',
            'public'        => true,
            'menu_position' => 25,
            'show_ui'       => true,
            'capability_type' => 'post',
            'hierarchical'  => false,
            'rewrite'       => true,
            'query_var'     => true,
            'supports'      => array('title','editor','thumbnail'),
            'menu_icon'     => get_stylesheet_directory_uri()  . '/img/store.png',
            'has_archive'   => true,
            'show_in_menu'  =>  true
       );
        register_post_type('merchandise',$args); 
    }
    add_action('init','merchandise');

    add_action( 'init', 'add_merchandise_category', 0 );

    function add_merchandise_category() {
        register_taxonomy(
            'merchandise_category',
            'merchandise',
            array(
                'labels' => array(
                    'name' => 'Category',
                    'add_new_item' => 'Add New Category',
                    'new_item_name' => "New Merchandise Category"
                ),
                'show_ui' => true,
                'show_tagcloud' => false,
                'hierarchical' => true
            )
        );
    }
    
    function merchandise_get_featured_image($post_ID) {  
        $post_thumbnail_id = get_post_thumbnail_id($post_ID);  
        if ($post_thumbnail_id) {  
            $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id,'featured_preview');  
            return $post_thumbnail_img[0];  
        }  
    }  
        // ADD NEW COLUMN  
    function merchandise_columns_head($defaults) {  
        $new_columns['cb'] = '<input type="checkbox" />';
        
        $new_columns['featured_image'] = ('Photo');
        $new_columns['title'] = _x('Title','column name');
        $new_columns['merchandise'] = ('Category');
     
        $new_columns['date'] = _x('Date','column name');
     
        return $new_columns;
        //$defaults['featured_image'] = 'Photo';  
        //return $defaults;  
    }  
      
    // SHOW THE FEATURED IMAGE  
    function merchandise_columns_content($column_name,$post_ID) {  
        if ($column_name == 'featured_image') {  
            $post_featured_image = merchandise_get_featured_image($post_ID);  
            if ($post_featured_image) {  
                echo '<div class="thumbnail" style="width:50px;height:50px;overflow:hidden;""><img src="' . $post_featured_image . '" style="height:50px;"/></div>';  
            }  
        }  
        if ($column_name == 'merchandise') {  
            $terms = get_the_terms($post->ID ,'merchandise_category');
            foreach ($terms as $term) {
                echo $term->name;
            }
        }  
    }  

    add_filter('manage_merchandise_posts_columns','merchandise_columns_head');  
    add_action('manage_merchandise_posts_custom_column','merchandise_columns_content',10,2);

    add_action('admin_head','merchandise_style');

    function merchandise_style() {
        echo '<style type="text/css">';
        echo '.column-featured_image { width:60px;text-align:center; }';
        echo '</style>';
    }
?>