<?php include('header.php') ?>

		<div class="komtek-content-single">
			<?php 
			$args = array(
				'post_type' => 'video',
			    'posts_per_page' => 8,
			    'paged' => ( get_query_var('paged') ? get_query_var('paged') : 1 ),
			);
			$gallery = new WP_Query( $args );
			?>
			<?php if ( $gallery->have_posts() ) : ?>
			<div class="undercat">

					<a href="#" style="text-transform:uppercase;background:#fff;padding-right:15px;">Gallery Video</a>

					<hr/>

				</div>

			<div class="single-posts">
				<div class="post-summary">
					<br/>
					<ul class="gallery">
					<?php while ( $gallery->have_posts() ) : $gallery->the_post(); ?>

				
						<li>
							<div class="post-thumbnail" style="height:auto">	
								<?php 
								$videoid = parse_yturl(get_post_meta(get_the_ID(), '_yt_video', true));
								?>
								<a href="<?=get_permalink()?>" title="<?php the_title(); ?>"><img src="http://img.youtube.com/vi/<?php echo $videoid; ?>/2.jpg" width="100%"/></a>
								<span class="title"><?php echo get_short_title(22); ?>...</span>
							</div>
						</li>

					<?php endwhile; ?>
					</ul>
				</div>
				<?php komtek_pagination($gallery->max_num_pages); ?>
			</div>
			
			<?php endif; ?>

		</div>

<?php include('footer.php') ?>