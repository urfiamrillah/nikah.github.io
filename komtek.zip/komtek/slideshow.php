
<div id="myCarousel" class="carousel slide">
			
	<a href="index.php?page_id=151" class="wolulas"></a>

	<?php slideshow_featured_posts(); ?>
	<div class="carousel-inner">
	<?php if (mytheme_option('category_slideshow') && mytheme_option('max_slideshow')):?>
		<?php $slideshow = mytheme_option('category_slideshow');?>
		<?php $max = mytheme_option('max_slideshow');?>
	<?php else:?>
		<?php $slideshow = "slideshow";?>
		<?php $max = "5";?>
	<?php endif;?>
	<?php query_posts('category_name='.$slideshow.'&showposts='.$max.'');?>
	<?php while (have_posts()) : the_post(); ?>
	<div class="item" style="height:300px;overflow:hidden;">
			<?php 
				$thumb = get_post_thumbnail_id(); 
			 	$image = vt_resize( $thumb,'' , 960, 300, true );
			?>
			<img src="<?php echo $image[url]; ?>" width="<?php echo $image[width]; ?>" height="<?php echo $image[height]; ?>" style="width:100%;"/>
			<div class="carousel-caption">
				<h3><?php the_title(); ?></h3>
				<p><?php the_excerpt(); ?></p>
				<a href="<?php the_permalink(); ?>">+ READ MORE</a>
			</div>
		</div>
	<?php endwhile; ?>
	<?php 
		wp_reset_query();
		remove_filter('excerpt_length','hook_excerpt_featured_length');
	?>
	</div>
	
	<a class="carousel-control left" href="#myCarousel" data-slide="prev" onclick="return false">&lsaquo;</a>
	<a class="carousel-control right" href="#myCarousel" data-slide="next" onclick="return false">&rsaquo;</a>

</div>