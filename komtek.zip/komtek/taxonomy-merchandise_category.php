<?php include('header.php') ?>

		<div class="komtek-content-single">

			<?php if ( have_posts() ) : ?>

			<div class="single-post pull-left">

				<div class="undercat">

					<a href="#" style="text-transform:uppercase;background:#fff;padding-right:15px;"><?php echo single_cat_title( '', false ) ?></a>

					<hr/>

				</div>

				<?php while ( have_posts() ) : the_post(); ?>

				<div class="post-summary">
					<?php if ( has_post_thumbnail() ):?>
					<div class="post-thumbnail">
						<?php the_post_thumbnail('slideshow'); ?>
					</div>
					

					<div class="post-title" style="margin-left:190px">

						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

						<span class="author"><?php the_author() ?></span>

					</div>

					<div class="post-entry" style="margin-left:190px">
						<?php echo get_short_post(150) .'...' ?>
						<br/>
						<a href="<?php the_permalink(); ?>">read more &raquo;</a>
					</div>

					<?php else:?>

					<div class="post-title">

						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>

						<span class="author"><?php the_author() ?></span>

					</div>

					<div class="post-entry">
						<?php echo get_short_post(150) .'...' ?>
						<br/>
						<a href="<?php the_permalink(); ?>">read more &raquo;</a>
					</div>

					<?php endif;?>

				</div>
				<?php endwhile; ?>
				<?php komtek_pagination();?>

			</div>
			
			<?php endif; ?>

			<div class="single-sidebar pull-right">
				<?php include 'sidebar-merchandise.php'?>
			</div>

		</div>

<?php include('footer.php') ?>